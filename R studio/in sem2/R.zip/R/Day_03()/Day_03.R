# Skewness
# Skewness(x, na.rm=FALSE)

time = c(1,2,3,4,5,6,7,8,9)
skewness(time, na.rm=TRUE)

# Kurtosis
kurtosis(time)