height = c(103,145,151,144,128,136)

quantile(height)

quantile(height, probs = seq(0,1,0.10))